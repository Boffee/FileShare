# Modified CNTK version of the Keras DQN version that was published at
# https://jaromiru.com/2016/10/03/lets-make-a-dqn-implementation/

import random, numpy, math, gym

#from keras.models import Sequential
#from keras.layers import *
#from keras.optimizers import *
from cntk import *
from cntk.models import Sequential
from cntk.layers import *

BATCH_SIZE_BASELINE = 50  # Avg reward over these many episodes
H = 64 # hidden layer size

class Brain:
    def __init__(self):
        self.model, self.trainer, self.loss = self._create()
        # self.model.load_weights("cartpole-basic.h5")
        self.params = {}

    def _create(self):
        observation = input_variable(STATE_COUNT, np.float32, name="s")
        q_target = input_variable(ACTION_COUNT, np.float32, name="q")

        USE_LAYER = True
        if USE_LAYER:
            # model = Sequential()
            # model.add(Dense(output_dim=64, activation='relu', input_dim=STATE_COUNT))
            # model.add(Dense(output_dim=ACTION_COUNT, activation='linear'))

            l1 = Dense(H, activation=relu)
            l2 = Dense(ACTION_COUNT)
            unbound_model = Sequential([l1, l2])

            self.params = dict(W1=l1.W, b1=l1.b, W2=l2.W, b2=l2.b)
            
            model = unbound_model(observation)
        else:
            W1 = parameter(shape=(STATE_COUNT, H), init=glorot_uniform(), name="W1")
            b1 = parameter(shape=H, name="b1")
            layer1 = relu(times(observation, W1) + b1)
            W2 = parameter(shape=(H, ACTION_COUNT), init=glorot_uniform(), name="W2")
            b2 = parameter(shape=ACTION_COUNT, name="b2")
            model = times(layer1, W2) + b2

        lr = 0.00025
        # opt = RMSprop(lr=0.00025)
        # model.compile(loss='mse', optimizer=opt)

        # loss='mse'

        loss =  reduce_mean(square(model - q_target), axis=0)
        meas = reduce_mean(square(model - q_target), axis=0)

        # optimizer=opt
        lr /= BATCH_SIZE
        learner = sgd(model.parameters, lr,
                gradient_clipping_threshold_per_sample=2.3)
        trainer = Trainer(model, loss, meas, learner)

        # CNTK: return trainer, loss as well
        return model, trainer, loss

    def train(self, x, y, epoch=1, verbose=0):
        #self.model.fit(x, y, batch_size=64, nb_epoch=epoch, verbose=verbose)
        arguments = dict(zip(self.loss.arguments, [y,x]))
        updated, results =self.trainer.train_minibatch(arguments, 
                outputs=[self.loss.output])

    def predict(self, s):
        return self.model.eval(s)

#-------------------- MEMORY --------------------------
class Memory:   # stored as ( s, a, r, s_ )
    samples = []

    def __init__(self, capacity):
        self.capacity = capacity

    def add(self, sample):
        self.samples.append(sample)        

        if len(self.samples) > self.capacity:
            self.samples.pop(0)

    def sample(self, n):
        n = min(n, len(self.samples))
        return random.sample(self.samples, n)

#-------------------- AGENT ---------------------------
MEMORY_CAPACITY = 100000
BATCH_SIZE = 64

GAMMA = 0.99

MAX_EPSILON = 1
MIN_EPSILON = 0.01
LAMBDA = 0.0001      # speed of decay

class Agent:
    steps = 0
    epsilon = MAX_EPSILON

    def __init__(self):
        self.brain = Brain()
        self.memory = Memory(MEMORY_CAPACITY)
        
    def act(self, s):
        if random.random() < self.epsilon:
            return random.randint(0, ACTION_COUNT-1)
        else:
            return numpy.argmax(self.brain.predict(s))

    def observe(self, sample):  # in (s, a, r, s_) format
        self.memory.add(sample)        

        # slowly decrease Epsilon based on our eperience
        self.steps += 1
        self.epsilon = MIN_EPSILON + (MAX_EPSILON - MIN_EPSILON) * math.exp(-LAMBDA * self.steps)

    def replay(self):    
        batch = self.memory.sample(BATCH_SIZE)
        batchLen = len(batch)

        no_state = numpy.zeros(STATE_COUNT)

        
        # CNTK: explicitly setting to float32
        states = numpy.array([ o[0] for o in batch ], dtype=np.float32)
        states_ = numpy.array([ (no_state if o[3] is None else o[3]) for o in batch ], dtype=np.float32)

        p = agent.brain.predict(states)
        p_ = agent.brain.predict(states_)

        # CNTK: explicitly setting to float32
        x = numpy.zeros((batchLen, STATE_COUNT)).astype(np.float32)
        y = numpy.zeros((batchLen, ACTION_COUNT)).astype(np.float32)
        
        for i in range(batchLen):
            s, a, r, s_ = batch[i]
            
            # CNTK: [0] because of sequence dimension
            t = p[0][i]
            if s_ is None:
                t[a] = r
            else:
                t[a] = r + GAMMA * numpy.amax(p_[0][i])

            x[i] = s
            y[i] = t

        self.brain.train(x, y)

#-------------------- ENVIRONMENT ---------------------
env = gym.make('CartPole-v0')

STATE_COUNT  = env.observation_space.shape[0]
ACTION_COUNT = env.action_space.n

def run(agent):
    s = env.reset()
    R = 0 

    while True:            
        #env.render()

        # CNTK: explicitly setting to float32
        a = agent.act(s.astype(np.float32))

        s_, r, done, info = env.step(a)

        if done: # terminal state
            s_ = None

        agent.observe( (s, a, r, s_) )
        agent.replay()            

        s = s_
        R += r

        if done:
            return R


agent = Agent()

try:
    episode_number = 0
    reward_sum = 0
    while True:
        reward_sum += run(agent)
        episode_number += 1
        if episode_number % BATCH_SIZE_BASELINE == 0:
            print('Episode: %d, Average reward for episode %f.' % (
                episode_number, reward_sum / BATCH_SIZE_BASELINE))
            if reward_sum / BATCH_SIZE_BASELINE > 200:
                print('Task solved in %d episodes' % episode_number)
                sys.exit(0)
            reward_sum = 0
finally:
    #agent.brain.model.save("cartpole-basic.h5")
    pass
