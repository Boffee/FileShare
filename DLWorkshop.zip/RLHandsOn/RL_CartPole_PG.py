import numpy as np
import cntk as C
import math

import gym

env = gym.make('CartPole-v0')

TOTAL_EPISODES = 10000

# hyperparameters
H = 10  # number of hidden layer neurons
BATCH_SIZE = 50  # every how many episodes to do a param update?
gamma = 0.99  # discount factor for reward
env.reset()

STATE_COUNT  = env.observation_space.shape[0]
ACTION_COUNT = env.action_space.n

def discount_rewards(r):
    """ take 1D float array of rewards and compute discounted reward """
    discounted_r = np.zeros_like(r)
    running_add = 0
    for t in reversed(range(0, r.size)):
        running_add = running_add * gamma + r[t]
        discounted_r[t] = running_add
    return discounted_r


def create():
    # This defines the network as it goes from taking an observation of the environment to
    # giving a probability of chosing to the action of moving left or right.
    observations = C.input_variable(shape=STATE_COUNT, data_type=np.float32, name="obs")
    W1 = C.parameter(shape=(STATE_COUNT, H), init=C.glorot_uniform(), name="W1")
    b1 = C.parameter(shape=H, name="b1")
    layer1 = C.relu(C.times(observations, W1) + b1)
    W2 = C.parameter(shape=(H, ACTION_COUNT), init=C.glorot_uniform(), name="W2")
    b2 = C.parameter(shape=ACTION_COUNT, name="b2")
    score = C.times(layer1, W2) + b2
    probability = C.sigmoid(score, name="prob")

    lr = 0.001  # learning rate

    input_y = C.input_variable(shape=1, data_type=np.float32, name="input_y")
    advantages = C.input_variable(shape=1, data_type=np.float32, name="advt")

    loss = -C.reduce_mean(C.log(C.square(input_y - probability) + 1e-4) * advantages, axis=0, name='loss')

    sgd = C.sgd([W1, W2], lr)

    gradBuffer = dict((var.name, np.zeros(shape=var.shape)) for var in loss.parameters if var.name in ['W1', 'W2', 'b1', 'b2'])

    xs, hs, label, drs = [], [], [], []
    running_reward = None
    reward_sum = 0
    episode_number = 1

    # Obtain an initial observation of the environment
    observation = env.reset()

    while episode_number <= TOTAL_EPISODES:
        x = np.reshape(observation, [1, STATE_COUNT]).astype(np.float32)

        # Run the policy network and get an action to take.
        prob = probability.eval(arguments={observations: x})[0][0][0]
        action = 1 if np.random.uniform() < prob else 0

        xs.append(x)  # observation
        # grad that encourages the action that was taken to be taken

        y = 1 if action == 0 else 0  # a "fake label"
        label.append(y)

        # step the environment and get new measurements
        observation, reward, done, info = env.step(action)
        reward_sum += float(reward)

        # record reward (has to be done after we call step() to get reward for previous action)
        drs.append(float(reward))

        if done:
            episode_number += 1
            # stack together all inputs, hidden states, action gradients, and
            # rewards for this episode
            epx = np.vstack(xs)
            epl = np.vstack(label).astype(np.float32)
            epr = np.vstack(drs).astype(np.float32)
            xs, label, drs = [], [], []  # reset array memory

            # compute the discounted reward backwards through time
            discounted_epr = discount_rewards(epr)
            # size the rewards to be unit normal (helps control the gradient
            # estimator variance)
            discounted_epr -= np.mean(discounted_epr)
            discounted_epr /= np.std(discounted_epr)

            arguments = {observations: epx, input_y: epl, advantages: discounted_epr}
            state, outputs_map = loss.forward(arguments, outputs=loss.outputs, keep_for_backward=loss.outputs)
            root_gradients = {v: np.ones_like(o) for v, o in outputs_map.items()}
            vargrads_map = loss.backward(state, root_gradients, variables=set([W1, W2]))

            for var, grad in vargrads_map.items():
                gradBuffer[var.name] += grad

            # Wait for some batches to finish to reduce noise
            if episode_number % BATCH_SIZE == 0:
                grads = {W1: gradBuffer['W1'].astype(np.float32), W2: gradBuffer['W2'].astype(np.float32)}
                updated = sgd.update(grads, BATCH_SIZE)

                # reset the gradBuffer
                gradBuffer = dict((var.name, np.zeros(shape=var.shape)) for var in loss.parameters if var.name in ['W1', 'W2', 'b1', 'b2'])

                print('Episode: %d. Average reward for episode %f.' % (episode_number, reward_sum / BATCH_SIZE))

                if reward_sum / BATCH_SIZE > 200:
                    print('Task solved in: %d ' % episode_number)
                    break

                reward_sum = 0

            observation = env.reset()  # reset env

if __name__ == '__main__':
    C.DeviceDescriptor.set_default_device(C.cpu())
    create()
