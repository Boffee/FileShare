# Run the CartPole model
import numpy as np
import cntk as C

import gym
env = gym.make('CartPole-v0')

upper_bound_reward = 1000  # set max rewards possible in one episode
num_episodes = 1  # number of episodes to run
D = 4  # observation from openai gym dimensionality

modelPath = 'dqn.mod'

root = C.load_model(modelPath)

for i_episode in range(num_episodes):
    decisions = []
    observation = env.reset()  # reset environment for new episode
    total_reward = 0  # reset total rewards for an episode
    for t in range(upper_bound_reward):
        env.render()
        print("observation:", observation)
        action = np.argmax(root.eval(observation.astype(np.float32)))

        decisions.append(action)
        observation, reward, done, info = env.step(action)
        total_reward += reward
        if done:
            print('Episode finished after %d timesteps, rewards:%d' %
                  (t + 1, total_reward))
            print(decisions)
            break

