To make this work without path issues please put the contents in a folder like this:

<CNTK_ROOT>/Tutorials/Sequence2Sequence

Please also invoke your Jupyter Notebook from <CNTK_ROOT> so that we have access to other data in the CNTK source tree.
(Jupyter Notebooks can only access data from within the root folder where they were launched).